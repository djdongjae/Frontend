// let p1 = { name: "홍길동", age: 16};
// let p2 = { name: "임꺽정", age: 19};
// let a = [p1, p2];

let a = [
    { name: "홍길동", age: 16},
    { name: "임꺽정", age: 19}
]

let p1 = a[0];
let p2 = a[1];

console.log(p1);
console.log(p2);